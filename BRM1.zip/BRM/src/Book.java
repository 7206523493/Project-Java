
public class Book {

	private  int bookid;
	private String title,publisher,auhtor;
	private double price;
	public int getbookid() {
		return bookid;
	}
	public void setbookid(int bookid) {
		this.bookid = bookid;
	}
	public String gettitle() {
		return title;
	}
	public void settitle(String title) {
		this.title = title;
	}
	public String getpublisher() {
		return publisher;
	}
	public void setpublisher(String publisher) {
		this.publisher = publisher;
	}
	public String getauhtor() {
		return auhtor;
	}
	public void setauhtor(String auhtor) {
		this.auhtor = auhtor;
	}
	public double getprice() {
		return price;
	}
	public void setprice(double price) {
		this.price = price;
	}
	
	}


